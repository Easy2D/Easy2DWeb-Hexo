#include <easy2d.h>
#include "resource.h"
#include "ClockPanel.h"

int WINAPI WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpCmdLine,
	int nCmdShow
)
{
	EApp app;

	EWindowStyle wStyle;
	wStyle.m_pIconID = (LPCTSTR)IDI_ICON1;

	if (app.init(L"SmartClock", 300, 300, wStyle))
	{
		auto panel = new ClockPanel();
		app.enterScene(panel);
		app.run();
	}
	return 0;
}