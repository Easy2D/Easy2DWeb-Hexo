#pragma once
#include <easy2d.h>

class Number;

class ClockPanel :
	public EScene
{
public:
	ClockPanel();
	~ClockPanel();

	void flushTime();

	bool onInactive() override;

protected:
	Number * secondNum;
	Number * minuteNum;
	Number * hourNum;
	ENode * clock;
};

