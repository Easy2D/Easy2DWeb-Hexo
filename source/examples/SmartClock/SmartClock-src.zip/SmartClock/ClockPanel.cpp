#include "ClockPanel.h"
#include "Number.h"
#include <iomanip>

ClockPanel::ClockPanel()
{
	using namespace std::chrono;

	this->secondNum = new Number(0);
	this->minuteNum = new Number(1);
	this->hourNum = new Number(2);

	this->clock = new ENode();
	clock->addChild(secondNum);
	clock->addChild(minuteNum);
	clock->addChild(hourNum);
	clock->setPos(EApp::getWidth() / 2, EApp::getHeight() / 2);
	this->add(clock);

	// ��ȡϵͳʱ��
	system_clock::time_point tNow = system_clock::now();
	time_t time = system_clock::to_time_t(tNow);
	// ��ʼ�����̷���
	struct tm tm;
	localtime_s(&tm, &time);
	clock->setRotation(-30 + (tm.tm_sec % 10) * 5);
	// ˢ�±���ʱ��
	this->flushTime();
}


ClockPanel::~ClockPanel()
{
}

void ClockPanel::flushTime()
{
	using namespace std::chrono;

	// ��ȡϵͳʱ��
	system_clock::time_point tNow = system_clock::now();
	time_t time = system_clock::to_time_t(tNow);

	struct tm convertTime;
	localtime_s(&convertTime, &time);

	// ˢ��ʱ��
	hourNum->setNumber(convertTime.tm_hour);
	minuteNum->setNumber(convertTime.tm_min);
	secondNum->setNumber(convertTime.tm_sec);

	// ��ת����
	if ((convertTime.tm_sec % 10) != 0)
	{
		clock->runAction(
			new EActionSequence(
				3,
				new EActionRotateTo(
					0.1f,
					-25 + (convertTime.tm_sec % 10) * 5
				),
				new EActionDelay(
					0.85f
				),
				new EActionCallback(
					std::bind(&ClockPanel::flushTime, this)
				)
			)
		);
	}
	else
	{
		// ִ��һ�ο��ٵ���ת����
		clock->runAction(
			new EActionSequence(
				3,
				new EActionLoop(
					new EActionTwo(
						new EActionRotateBy(
							0.025f,
							-5
						),
						new EActionDelay(
							0.025f
						)
					),
					8
				),
				new EActionDelay(
					0.55f
				),
				new EActionCallback(
					std::bind(&ClockPanel::flushTime, this)
				)
			)
		);
	}
}

bool ClockPanel::onInactive()
{
	// ֱ�ӷ��� false����ʾ����ʧȥ����ʱ����ͣ
	return false;
}
