#include "Number.h"
#include "resource.h"


Number::Number(int mode)
{
	this->setScaleY(1.33f);
	this->setMode(mode);
}


Number::~Number()
{
}

void Number::setMode(int mode)
{
	this->mode = mode;

	switch (mode)
	{
	case 0:
	{
		this->setSkewY(30);
		this->setRotation(-60);
		this->setScaleY(1.5f);
	}
	break;
	case 1:
	{
		this->setSkewY(-30);
		this->setRotation(0);
	}
	break;
	case 2:
	{
		this->setSkewY(30);
		this->setRotation(0);
	}
	break;
	default:
		break;
	}
}

void Number::setNumber(int num)
{
	this->clearAllChildren();

	int num1 = num / 10;
	int num2 = num % 10;

	int num1X = 24 * num1;
	int num1Y = 36 * mode;
	int num2X = 24 * num2;
	int num2Y = 36 * mode;

	auto num1Sprite = new ESprite(MAKEINTRESOURCE(IDB_PNG_NUMBERS), L"IMAGE", num1X, num1Y, 24, 36);
	auto num2Sprite = new ESprite(MAKEINTRESOURCE(IDB_PNG_NUMBERS), L"IMAGE", num2X, num2Y, 24, 36);

	this->addChild(num1Sprite);
	this->addChild(num2Sprite);

	switch (mode)
	{
	case 0:
	{
		num1Sprite->setPivot(0, 1);
		num2Sprite->setPivot(0, 1);
		num2Sprite->setPosX(24);
	}
	break;
	case 1:
	{
		num1Sprite->setPivot(0, 0);
		num2Sprite->setPivot(0, 0);
		num2Sprite->setPosX(24);
	}
	break;
	case 2:
	{
		num1Sprite->setPivot(1, 0);
		num1Sprite->setPosX(-24);
		num2Sprite->setPivot(1, 0);
	}
	break;
	default:
		break;
	}
}
