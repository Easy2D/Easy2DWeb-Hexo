#pragma once
#include <easy2d.h>
#include "Number.h"

class ClockPanel :
	public Node
{
public:
	ClockPanel();

	void onUpdate();

	// ˢ��ʱ��
	void Flush();

protected:
	float lastTime;
	Number * secondNum;
	Number * minuteNum;
	Number * hourNum;
};

