#include <easy2d.h>
#include "resource.h"
#include "ClockPanel.h"

int WINAPI WinMain(
	HINSTANCE hInstance,
	HINSTANCE hPrevInstance,
	LPSTR lpCmdLine,
	int nCmdShow
)
{
	if (Game::init(L"SmartClock", 300, 300, (LPCTSTR)IDI_ICON1))
	{
		// ����һ���ճ���
		auto scene = new Scene();
		SceneManager::enterScene(scene);

		// ����һ������
		auto panel = new ClockPanel();
		scene->add(panel);

		Game::run();
	}
	Game::uninit();
	return 0;
}