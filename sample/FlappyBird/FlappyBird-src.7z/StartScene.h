#pragma once
#include <easy2d.h>

class StartScene :
	public Scene
{
public:
	StartScene();
	void onEnter() override;
};

