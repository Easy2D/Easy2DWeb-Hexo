#pragma once
#include <easy2d.h>

class SplashScene :
	public Scene
{
public:
	SplashScene();

	void start();
};
