#pragma once
#include "easy2d.h"


class LevelSelectScene :
	public Scene
{
public:
	LevelSelectScene();

	void initJungle();
	void initChina();
	void initEgypt();
	void initButton();
	void movePanel();

protected:
	Node *	panel;
	int		level;
};

