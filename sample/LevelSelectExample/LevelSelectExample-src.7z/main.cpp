#include <easy2d.h>
#include "resource.h"
#include "LevelSelectScene.h"

int main()
{
	if (Game::init(L"�ؿ�ѡ��", 320, 480, (LPCTSTR)IDI_ICON1))
	{
		// ���� LevelSelectScene ����
		auto scene = new LevelSelectScene();
		SceneManager::enterScene(scene);

		Game::run();
	}

	Game::uninit();
	return 0;
}